import java.io.BufferedReader;
import java.io.InputStreamReader;


public class test {
	public static void main(String [] r){
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		System.out.println(2 << 1);
		
	}

}
