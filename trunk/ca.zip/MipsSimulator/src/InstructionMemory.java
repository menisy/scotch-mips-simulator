import java.util.ArrayList;
import java.util.HashMap;

public class InstructionMemory {
	private int pc;
	boolean done;
	HashMap<Integer, String> instructions = new HashMap<Integer, String>();

	public InstructionMemory(ArrayList<String> file) {
		String firstLine = file.get(0);
		String[] arr = firstLine.split(" ");
		int startingAddress;
		if (arr[0].equalsIgnoreCase("ORG"))
			startingAddress = Integer.parseInt(arr[1]);
		else
			startingAddress = 0;
		for (int i = 1, j = startingAddress; i < file.size(); i++, j += 4) {
			instructions.put(j, file.get(i));
		}
	}
	public boolean isDone(){
		return done;
	}
	public int getPC() {
		return pc;
	}

	public String fetchInstruction() {
		String instruction = instructions.get(pc);
		String [] arr = instruction.split(" ");
		if(arr[0].equalsIgnoreCase("end")) done = true;
		pc += 4;
		return instruction;
	}
}
