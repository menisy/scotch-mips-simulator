
public class ALU_MUX extends MUX{
	ALU alu;
	public ALU_MUX(ALU alu){
		this.alu = alu;
	}
	public void forward(){
		alu.setOp2(this.getOutput());
	}
}
