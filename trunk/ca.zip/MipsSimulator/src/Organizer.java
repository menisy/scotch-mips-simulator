import java.io.File;
import java.util.ArrayList;


public class Organizer {
	InstructionMemory instructionMemory;
	RegistersFile registers;
	ALU alu;
	MUX aluMUX,regMUX,pcMUX;
	public Organizer(ArrayList<String> file){
		instructionMemory = new InstructionMemory(file);
		registers = new RegistersFile();
		alu = new ALU();
		aluMUX = new ALU_MUX(alu);
	// TODO	regMUX = new MUX();
	// TODO	pcMUX = new MUX();
		start();
	}
	public void start(){
		while(!instructionMemory.isDone()){
			String inst = instructionMemory.fetchInstruction();
			decode(inst);
		}
	}
	public void decode(String inst){
		String [] arr = inst.split(" ");
		String op = arr[0];
		if(op.equalsIgnoreCase("add")){
			alu.setControl(1);
			aluMUX.setSelect(0);
		}else if(op.equalsIgnoreCase("addi")){
			alu.setControl(1);
			aluMUX.setSelect(1);
		}else if(op.equalsIgnoreCase("sub")){
			alu.setControl(2);
			aluMUX.setSelect(0);
		}else if(op.equalsIgnoreCase("lw")){
			alu.setControl(1); // TODO 
		}else if(op.equalsIgnoreCase("sw")){
			alu.setControl(1); // TODO
		}else if(op.equalsIgnoreCase("sll")){
			alu.setControl(6);
		}else if(op.equalsIgnoreCase("srl")){
			alu.setControl(5);
		}else if(op.equalsIgnoreCase("and")){
			alu.setControl(4);
			aluMUX.setSelect(0);
		}else if(op.equalsIgnoreCase("andi")){
			alu.setControl(4);
			aluMUX.setSelect(1);
		}else if(op.equalsIgnoreCase("or")){
			alu.setControl(3);
			aluMUX.setSelect(0);
		}else if(op.equalsIgnoreCase("ori")){
			alu.setControl(3);
			aluMUX.setSelect(1);
		}else if(op.equalsIgnoreCase("nor")){
			alu.setControl(7);
			aluMUX.setSelect(0);
		}else if(op.equalsIgnoreCase("beq")){
			alu.setControl(1); // TODO
		}else if(op.equalsIgnoreCase("bne")){
			alu.setControl(1); // TODO
		}else if(op.equalsIgnoreCase("j")){
			alu.setControl(1); // TODO
		}else if(op.equalsIgnoreCase("jal")){
			alu.setControl(1); // TODO
		}else if(op.equalsIgnoreCase("jr")){
			alu.setControl(1); //TODO
		}else if(op.equalsIgnoreCase("slt")){
			alu.setControl(1); //TODO
		}else if(op.equalsIgnoreCase("slti")){
			alu.setControl(1); // TODO
		}else if(op.equalsIgnoreCase("sltu")){
			alu.setControl(1); // TODO
		}else if(op.equalsIgnoreCase("sltui")){
			alu.setControl(1); // TODO
		}
		
	}
	public static void main(String [] args){
			
	}
	
}
