
public abstract class MUX {
	int [] inputs;
	int out;
	int select;
	public void setInputs(int [] in){
		inputs = in;
	}
	public void setSelect(int sel){
		select = sel;
	}
	public int getOutput(){
		return inputs[select];
	}
	public abstract void forward();
}
